<script src="{{asset('public/home/js/jquery-2.1.0.min.js')}}"></script>
		<script src="{{asset('public/home/js/jquery-migrate-1.2.1.min.js')}}"></script>
		<script src="{{asset('public/home/js/retina.js')}}"></script>
		<script src="{{asset('public/home/js/camera.min.js')}}"></script>
		<script src="{{asset('public/home/js/jquery.easing.1.3.js')}}"></script>
		<script src="{{asset('public/home/js/waypoints.min.js')}}"></script>
		<script src="{{asset('public/home/js/jquery.isotope.min.js')}}"></script>
		<script src="{{asset('public/home/js/owl.carousel.min.js')}}"></script>
		<script src="{{asset('public/home/js/jquery.tweet.min.js')}}"></script>
		<script src="{{asset('public/home/js/jquery.custom-scrollbar.js')}}"></script>
		<script src="{{asset('public/home/js/scripts.js')}}"></script>
		 
<script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=xa-5306f8f674bfda4c"></script>
<script src="{{asset('public/home/js/jquery-2.1.0.min.js')}}"></script>