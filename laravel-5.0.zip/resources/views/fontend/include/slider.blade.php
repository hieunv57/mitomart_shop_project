<div class="camera_wrap m_bottom_0">
                <div data-src="{{asset('public/images/slide1.jpg')}}" data-custom-thumb="{{asset('public/images/slide1.jpg')}}">
                    <div class="camera_caption_1 fadeFromTop t_align_c d_xs_none">
                        <div class="f_size_large color_light tt_uppercase slider_title_3 m_bottom_5">Mito Mart</div>
                        <hr class="slider_divider d_inline_b m_bottom_5">
                        <div class="color_light slider_title tt_uppercase t_align_c m_bottom_45 m_sm_bottom_20"><b>Khai trương website</b></div>
                        <div class="color_light slider_title_2 m_bottom_45">Giảm giá nhiều sản phẩm</div>
                        <a href="#" role="button" class="tr_all_hover button_type_4 bg_scheme_color color_light r_corners tt_uppercase">Mua ngay</a>
                    </div>
                </div>
                <div data-src="{{asset('public/images/slide2.jpg')}}"  data-custom-thumb="images/slide_01.jpg">
                    <div class="camera_caption_2 fadeIn t_align_c d_xs_none">
                        <div class="f_size_large tt_uppercase slider_title_3 scheme_color">Khuyến mãi lớn</div>
                        <hr class="slider_divider type_2 m_bottom_5 d_inline_b">
                        <div class="color_light slider_title tt_uppercase t_align_c m_bottom_65 m_sm_bottom_20"><b><span class="scheme_color">Khuyến mãi lớn từ 20/4-30/4</span><br><span class="color_dark"></span></b></div>
                        <a href="#" role="button" class="d_sm_inline_b button_type_4 bg_scheme_color color_light r_corners tt_uppercase tr_all_hover">Xem chi tiết</a>
                    </div>
                </div>
                <div data-src="{{asset('public/images/slide3.jpg')}}" data-custom-thumb="images/slide_03.jpg">
                    <div class="camera_caption_3 fadeFromTop t_align_c d_xs_none">
                        
                        <div class="color_light slider_title tt_uppercase t_align_c m_bottom_60 m_sm_bottom_20"><span class="scheme_color">Đặt hàng nhanh gọn -  thanh toán dễ dàng</span></div>
                        <a href="#" role="button" class="d_sm_inline_b button_type_4 bg_scheme_color color_light r_corners tt_uppercase tr_all_hover">Mua ngay</a>
                    </div>
                </div>
            </div>