<?php namespace App\Http\Controllers\User;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Products;
use Illuminate\Http\Request;

class ListProductController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function sanphammoi()
	{
		$product_new_20 = new Products;
		$product_new_20 = $product_new_20->find_New(1000)->paginate(9);
		$product_new_20->setPath('san-pham-moi');
		$total = $product_new_20 -> count();
		return view('fontend.pages.san-pham.san-pham-moi', compact('product_new_20','total'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function sanphamxemnhieu()
	{
		$products = new Products;
		$products = $products->findMostView(1000)->paginate(9);
		$products->setPath('san-pham-duoc-quan-tam');
		$total = $products -> count();
		return view('fontend.pages.san-pham.san-pham-duoc-quan-tam', compact('products'));
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function sanphamgiamgia()
	{
		$product_sale = new Products;
		$product_sale = $product_sale->findSale()->paginate(9);
		$product_sale->setPath('san-pham-dang-giam-gia');
		$total = $product_sale -> count();
		return view('fontend.pages.san-pham.san-pham-dang-giam-gia', compact('product_sale'));
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function sanphamhot()
	{
		$product_hot = new Products;
		$product_hot = $product_hot->findHot(1000)->paginate(9);
		$product_hot->setPath('san-pham-hot');
		$total = $product_hot -> count();
		return view('fontend.pages.san-pham.san-pham-hot', compact('product_hot','total'));
	}

	

}
